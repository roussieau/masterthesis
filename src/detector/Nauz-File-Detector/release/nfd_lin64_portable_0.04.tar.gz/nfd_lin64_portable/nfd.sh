#!/bin/sh
export LD_LIBRARY_PATH="./base:"
./base/nfd 
